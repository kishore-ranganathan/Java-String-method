package string;

import java.util.Scanner;

public class equal_Ignorcase {
    public static void main(String[] args) {
        String str1 = "ABC";
        String str2 = "ABC";
        String str3 = str1;
        System.out.println(str1.equalsIgnoreCase(str2));
        System.out.println(str1 == str2);
        System.out.println(str2 == str3);
        System.out.println(str1.equals(str2));
        System.out.println(str2.equals(str3));
    }
}