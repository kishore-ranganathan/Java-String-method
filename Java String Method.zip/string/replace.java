package string;

public class replace {
    public static void main(String[] args) {
        String num = "apple";
        String str = "";
        System.out.println(str.replace(str, num));

    }
}
