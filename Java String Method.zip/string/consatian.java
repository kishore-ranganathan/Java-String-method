package string;

public class consatian {

}
