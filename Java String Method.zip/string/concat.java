package string;

public class concat {
    public static void main(String[] args) {
        String str1 = "hello";
        String str2 = "world";
        String str3 = str1 + str2;
        System.out.println(str3);
        System.out.println(str1.concat(str2));
    }

}
