package string;

import java.util.Scanner;

public class special_num {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.nextLine();
    int count = 0;
    int count1 = 0;
    String str=input.toUpperCase();for(
    int i = 0;i<input.length();i++)
    {
        if (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') {
            continue;
        } else if (str.charAt(i) >= '0' && str.charAt(i) <= '9') {
            count++;
        } else {
            count1++;
        }

        System.out.println(count1 + count);
    }
}
