package string;

public class index_compareto {

    public static void main(String[] args) {
        String[] str = { "ABCABC", "abcd" };
        System.out.print(str[0].compareTo(str[1]));
    }
}