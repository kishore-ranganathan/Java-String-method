package string;

public class contains {
    public static void main(String[] args) {
        String str1 = "123";
        String str2 = "234";
        String str3 = "123";
        System.out.println(str1.contains(str2));
        System.out.println(str1.contains(str3));
    }
}
