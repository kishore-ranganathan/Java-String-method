package string;

public class str_length {
    public static void main(String[] args) {
        String str = "hello world";
        System.out.println(str.length());
    }
}
