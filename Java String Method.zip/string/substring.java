package string;

public class substring {
    public static void main(String[] args) {
        String str = "hello world";
        System.out.println(str.substring(0, 6));
    }

}
