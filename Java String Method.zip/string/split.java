package string;

import java.util.Arrays;

public class split {
    public static void main(String[] args) {
        String str = "hello world";
        System.out.println(Arrays.toString(str.split(" ")));
    }
}
