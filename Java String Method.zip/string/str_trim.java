package string;

public class str_trim {
    public static void main(String[] args) {
        String str = "    hello   ";
        System.out.println(str.trim());
        System.out.println(str);
    }
}
