package string;

public class indexof {
    public static void main(String[] args) {
        String str1 = "12345";
        String str2 = "1234";
        System.out.println(str1.indexOf("3"));
        // System.out.println(str1.indexOf(str2));
    }

}
