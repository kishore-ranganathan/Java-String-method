package string;

import java.util.Scanner;

public class str {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fruit = " Apple ";
        System.out.println(fruit);
    }

}
