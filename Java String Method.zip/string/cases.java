package string;

import java.util.Scanner;

public class cases {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fruit_1 = "APPLEE";
        String fruit_2 = "apple";
        System.out.println(fruit_2.toUpperCase());
        System.out.println(fruit_1.toLowerCase());
    }

}
